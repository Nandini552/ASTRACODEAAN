from flask import Flask, render_template
import subprocess
import os
import signal

app = Flask(__name__, static_url_path='/static')

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/start')
def start():
    try:
        result = subprocess.run(['python', 'astra.py'], capture_output=True, text=True, check=True)
        return result.stdout
    except subprocess.CalledProcessError as e:
        return f"Error: {e}"

@app.route('/stop')
def stop():
    os.kill(os.getpid(), signal.SIGINT)
    return "Server stopped!"

if __name__ == '__main__':  # Corrected line
    app.run(debug=True, host='0.0.0.0', port=5000)
