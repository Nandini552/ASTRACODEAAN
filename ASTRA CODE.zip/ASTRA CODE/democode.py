import mysql.connector

def create_database():
    # Connect to MySQL server
    conn = mysql.connector.connect(
        host="localhost",
        user="root",  # Replace with your MySQL username
        password="",  # Replace with your MySQL passwNord
    )
    cursor = conn.cursor()

    # Create database if it doesn't exist
    cursor.execute("CREATE DATABASE IF NOT EXISTS students_db")
    cursor.close()
    conn.close()

    # Connect to the newly created database
    conn = mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="students_db"
    )
    cursor = conn.cursor()

    # Create a table for students if it doesn't exist
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS students (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(255) NOT NULL,
            age INT NOT NULL
        )
    ''')

    conn.commit()
    cursor.close()
    conn.close()

def insert_student(name, age):
    # Connect to the MySQL database
    conn = mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="students_db"
    )
    cursor = conn.cursor()

    # Insert the student's name and age into the table
    cursor.execute('INSERT INTO students (name, age) VALUES (%s, %s)', (name, age))

    conn.commit()
    cursor.close()
    conn.close()

def main():
    create_database()

    while True:
        print("\nEnter student details:")
        name = input("Name: ")
        age = input("Age: ")

        # Validate age input
        if not age.isdigit():
            print("Invalid age. Please enter a number.")
            continue

        insert_student(name, int(age))
        print(f"Student {name} (Age: {age}) added successfully!")

        another = input("Do you want to add another student? (yes/no): ").strip().lower()
        if another != 'yes':
            break

    print("\nAll students added successfully!")

if __name__ == "__main__":
    main()
